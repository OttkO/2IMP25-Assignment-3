"""sparsetools - a collection of routines for sparse matrix operations"""

from ._traversal import connected_components

__all__ = ["connected_components"]
