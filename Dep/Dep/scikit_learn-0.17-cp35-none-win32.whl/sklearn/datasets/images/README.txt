Image: china.jpg
Released under a creative commons license. [1]
Attribution: Some rights reserved by danielbuechele [2]
Retrieved 21st August, 2011 from [3] by Robert Layton

[1] http://creativecommons.org/licenses/by/2.0/
[2] http://www.flickr.com/photos/danielbuechele/
[3] http://www.flickr.com/photos/danielbuechele/6061409035/sizes/z/in/photostream/


Image: flower.jpg
Released under a creative commons license. [1]
Attribution: Some rights reserved by danielbuechele [2]
Retrieved 21st August, 2011 from [3] by Robert Layton

[1] http://creativecommons.org/licenses/by/2.0/
[2] http://www.flickr.com/photos/vultilion/
[3] http://www.flickr.com/photos/vultilion/6056698931/sizes/z/in/photostream/



